
# Build Instructions

pip install -r requirements.txt

pyinstaller --onefile secure_encryptor.py
pyinstaller --onefile --windowed gui_encryptor.py
